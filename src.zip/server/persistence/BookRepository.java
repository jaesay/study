package server.persistence;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import config.DBCPConfig;
import domain.Movie;

public class BookRepository {

	private DBCPConfig dbcpConfig;
		
	public List<Movie> findScheduledMovieList() throws SQLException {

		String sql = "SELECT DISTINCT m.* FROM movies m INNER JOIN schedules s ON m.movie_id = s.movie_id WHERE DATE(schedule_date) > CURDATE()";

		dbcpConfig = DBCPConfig.getDataSource();
		Connection connection = dbcpConfig.getConnection();
		PreparedStatement preparedStatement = connection.prepareStatement(sql);
		ResultSet resultSet = preparedStatement.executeQuery();
		

		List<Movie> movies = new ArrayList<>();

		if (resultSet.isBeforeFirst() ) {    
			while (resultSet.next()) {
				Movie movie = new Movie();
				
				movie.setMovieId(resultSet.getInt("movie_id"));
				movie.setTitle(resultSet.getString("title"));
				movie.setDirector(resultSet.getString("director"));
				movie.setContent(resultSet.getString("content"));
				movie.setActor(resultSet.getString("actor"));
				movie.setMovieImage(resultSet.getString("movie_image"));
				movie.setRating(resultSet.getFloat("rating"));
				movie.setRatingCount(resultSet.getInt("rating_count"));
				movie.setMemberId(resultSet.getInt("member_id"));
				movie.setCreatedDate(resultSet.getTimestamp("created_date"));
				movie.setUpdatedDate(resultSet.getTimestamp("updated_date"));
				
				movies.add(movie);
			}
		} else {
			movies = null;
		}
		
		// Connection�� ����ϰ� �ݳ��� �ؾ� Pooling�� �ȴ�.
		DBCPConfig.getDataSource().freeConnection(connection, preparedStatement, resultSet);

		return movies;
	}

	public List<Map<String, String>> findMovieSchedule(int movie_id) throws SQLException {
		
		String sql = "SELECT s.schedule_id, s.schedule_date, s.theater_id " +
				   	 "FROM schedules s INNER JOIN movies m ON m.movie_id = s.movie_id " +
				     "WHERE m.movie_id = ? AND DATE(schedule_date) > CURDATE()";
		
		List<Map<String, String>> resultList = new ArrayList<>(); 
		
		dbcpConfig = DBCPConfig.getDataSource();
		Connection connection = dbcpConfig.getConnection();
		PreparedStatement preparedStatement = connection.prepareStatement(sql);

		preparedStatement.setInt(1, movie_id);
		ResultSet resultSet = preparedStatement.executeQuery();
		
		while (resultSet.next()) {
			Map<String, String> resultMap = new HashMap<>(); 
			resultMap.put("scheduleId", resultSet.getString("schedule_id"));
			resultMap.put("scheduleDate", resultSet.getString("schedule_date"));
			resultMap.put("theaterId", resultSet.getString("theater_id"));
			resultList.add(resultMap);
		}
		
		// Connection�� ����ϰ� �ݳ��� �ؾ� Pooling�� �ȴ�.
		DBCPConfig.getDataSource().freeConnection(connection, preparedStatement, resultSet);
		
		return resultList;
	}

	public List<Map<String, String>> findSeats(int scheduleId) throws SQLException {
		
		String sql = "select se.seat_id, se.available from schedules s " + 
					"inner join movies m on s.movie_id = m.movie_id " + 
					"inner join theaters t on s.theater_id = t.theater_id " + 
					"inner join seats se on se.theater_id = t.theater_id " + 
					"where schedule_id = ?";
		
		List<Map<String, String>> resultList = new ArrayList<>(); 
		
		dbcpConfig = DBCPConfig.getDataSource();
		Connection connection = dbcpConfig.getConnection();
		PreparedStatement preparedStatement = connection.prepareStatement(sql);
		
		preparedStatement.setInt(1, scheduleId);
		ResultSet resultSet = preparedStatement.executeQuery();
		
		while (resultSet.next()) {
			Map<String, String> resultMap = new HashMap<>(); 
			resultMap.put("seatId", resultSet.getString("seat_id"));
			resultMap.put("available", resultSet.getString("available"));
			resultList.add(resultMap);
		}
		
		// Connection�� ����ϰ� �ݳ��� �ؾ� Pooling�� �ȴ�.
		DBCPConfig.getDataSource().freeConnection(connection, preparedStatement, resultSet);
		
		return resultList;
	}
}
