package helper.validator;

public class MemberValidator {
	
}
